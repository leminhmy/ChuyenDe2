package com.anhkhiem.shoppingonlinepostal.Main;


import android.os.Bundle;

import com.anhkhiem.shoppingonlinepostal.R;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addContenView(R.layout.activity_main);
    }
}